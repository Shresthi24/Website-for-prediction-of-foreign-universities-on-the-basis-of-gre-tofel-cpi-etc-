clc;
clear all;
close all;

data = dlmread('calcivil.csv',',',1,0);
data(:,[1]) = [];


A=ones(401,1);
data=real([A data]) ;
w0=rand();
w1=rand();
w2=rand();
w3=rand() ;
w4=rand();
w5=rand();
w6=rand();

w=[w0 w1 w2 w3 w4 w5 w6 ] ;
data=data(1:50,:);
data= data(randperm(50),:);
[rows,cols]=size(data);

E_in=[];
w_in=[];
for j=1:100
count=0;
  for i=1:rows
  ct=data(i,1:7);
  cfinal=dot(w,ct);
  cfin=sign(cfinal);
  output=data(i,13);
  
    if(output==cfin)
   % disp("classified")
    else
    %disp("disclassified")
    wf=output.*ct;
		w=w.+wf;
    count++;
    end
   
   end
   w_in=[w_in;w];
   E_in=[E_in ;count];
end
w_min=[];
w_min1=w_in(1,:);
E_min=[];
E_min1=E_in(1,:);

for i=1:100
  if(E_in(i,:)<E_min1)
  E_min1=E_in(1,:);
  w_min1=w_in(i,:);
  else
  E_min1=E_min1;
  end
  E_min=[E_min;E_min1];
  w_min=[w_min;w_min1];
end
disp(w_min(end,:))
disp(E_min(end,:))

##for modified
weig=w_min(end,:);
data1 = dlmread('calcivilfin.csv',',',1,0);
data1(:,[1]) = [];
A1=ones(401,1);
counta=0;
data1=[A1 data1] ;
B=zeros(401,1);

data1=[data1 B];

data1=data1(1:50,:);
for i=1:rows
  
cfinal= (data1(i,1)*w_min(end,1)+data1(i,2)*w_min(end,2)+data1(i,3)*w_min(end,4)+data1(i,4)*w_min(end,5)+data1(i,5)*w_min(end,6)+data1(i,6)*w_min(end,7)+(1.*data1(i,7)*w_min(end,2))+((3*data1(i,8)*w_min(end,2))/2)+(2*data1(i,9)*w_min(end,2)));
  cfin=sign(cfinal);
  data1(i,10)=cfin;
 if(cfin==-1)
  counta++;
  end
        end
     
        disp(counta);
     
        dlmwrite ("caltechmum_civilmod.csv", data1, ",")


